#!/usr/bin/env python
# encoding=utf-8


def ampt2():
    print("Hello ampt2 (v0.0.2) ~")
